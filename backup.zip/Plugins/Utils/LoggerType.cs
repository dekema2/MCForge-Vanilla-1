﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MCForge
{
    /// <summary>
    /// The type of log that was created
    /// </summary>
    public enum LogType
    {
        Normal,
        OpLog,
        AdminLog
    }
}
